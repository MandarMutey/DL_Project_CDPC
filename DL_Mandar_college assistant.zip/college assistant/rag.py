
import os
from pathlib import Path

import chromadb
import fitz
import requests
from sentence_transformers import SentenceTransformer

# Project paths
ROOT = Path(__file__).resolve().parent
DEFAULT_DOCS_DIR = ROOT / "sample_documents"
DB_DIR = ROOT / "chroma_db"

# Local AI configuration
EMBED_MODEL = os.getenv(
    "EMBED_MODEL",
    "sentence-transformers/all-MiniLM-L6-v2"
)
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2:3b")
OLLAMA_URL = os.getenv(
    "OLLAMA_URL",
    "http://localhost:11434"
)

COLLECTION_NAME = "college_documents"

ABSTAIN = (
    "I couldn't find sufficient evidence in the "
    "indexed college documents to answer that question."
)


def read_document(path):
    """Extract text from a PDF or TXT document."""

    records = []

    if path.suffix.lower() == ".pdf":
        with fitz.open(path) as pdf:
            for page_number, page in enumerate(pdf, start=1):
                text = page.get_text().strip()

                if text:
                    records.append({
                        "text": text,
                        "source": path.name,
                        "location": f"page {page_number}"
                    })

    elif path.suffix.lower() == ".txt":
        text = path.read_text(
            encoding="utf-8",
            errors="replace"
        ).strip()

        if text:
            line_count = len(text.splitlines())

            records.append({
                "text": text,
                "source": path.name,
                "location": f"lines 1-{line_count}"
            })

    return records


def chunk_text(text, chunk_size=850, overlap=120):
    """Split text into overlapping chunks."""

    if chunk_size <= overlap:
        raise ValueError(
            "chunk_size must be larger than overlap"
        )

    chunks = []
    start = 0

    while start < len(text):
        end = min(start + chunk_size, len(text))
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        if end == len(text):
            break

        start = end - overlap

    return chunks


class KnowledgeAssistant:

    def __init__(self):
        self.embedder = SentenceTransformer(EMBED_MODEL)

        self.client = chromadb.PersistentClient(
            path=str(DB_DIR)
        )

        self.collection = (
            self.client.get_or_create_collection(
                name=COLLECTION_NAME,
                metadata={"hnsw:space": "cosine"}
            )
        )

    def ingest(self, directories):
        """Read documents and add their chunks to ChromaDB."""

        documents = []
        ids = []
        metadatas = []
        seen_paths = set()

        for directory in directories:
            directory = Path(directory)

            if not directory.exists():
                continue

            for path in sorted(directory.iterdir()):

                if not path.is_file():
                    continue

                if path.suffix.lower() not in {".txt", ".pdf"}:
                    continue

                resolved_path = str(path.resolve())

                if resolved_path in seen_paths:
                    continue

                seen_paths.add(resolved_path)

                records = read_document(path)

                for record_number, record in enumerate(records):

                    chunks = chunk_text(record["text"])

                    for chunk_number, chunk in enumerate(chunks):

                        chunk_id = (
                            f"{path.name}:"
                            f"{record_number}:"
                            f"{chunk_number}"
                        )

                        documents.append(chunk)
                        ids.append(chunk_id)

                        metadatas.append({
                            "source": record["source"],
                            "location": record["location"],
                            "chunk": chunk_number
                        })

        if not documents:
            raise ValueError(
                "No readable PDF or TXT documents found."
            )

        embeddings = self.embedder.encode(
            documents,
            normalize_embeddings=True
        ).tolist()

        self.collection.upsert(
            ids=ids,
            documents=documents,
            metadatas=metadatas,
            embeddings=embeddings
        )

        return len(documents)

    def retrieve(self, question, top_k=4):
        """Find passages most relevant to a question."""

        if self.collection.count() == 0:
            raise RuntimeError(
                "Knowledge base is empty. Ingest documents first."
            )

        question_embedding = self.embedder.encode(
            [question],
            normalize_embeddings=True
        ).tolist()[0]

        results = self.collection.query(
            query_embeddings=[question_embedding],
            n_results=min(top_k, self.collection.count()),
            include=[
                "documents",
                "metadatas",
                "distances"
            ]
        )

        passages = []

        for document, metadata, distance in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0]
        ):
            passages.append({
                "text": document,
                "source": metadata["source"],
                "location": metadata["location"],
                "score": max(0.0, 1.0 - float(distance))
            })

        return passages

    
    def answer(
        self,
        question,
        top_k=4,
        min_similarity=0.30
    ):
        passages = self.retrieve(
            question,
            top_k=top_k
        )

        selected = [
            p for p in passages
            if p["score"] >= min_similarity
        ]

        if not selected:
            return {
                "answer": ABSTAIN,
                "sources": []
            }

        # Keep your context-building code here.

        prompt = f"""
Your prompt text goes here.
"""

        try:
            response = requests.post(
                f"{OLLAMA_URL}/api/generate",
                json={
                    "model": OLLAMA_MODEL,
                    "prompt": prompt,
                    "stream": False,
                    "options": {"temperature": 0}
                },
                timeout=180
            )

            response.raise_for_status()

            answer = response.json().get(
                "response", ""
            ).strip()

            if not answer:
                answer = ABSTAIN

        except requests.RequestException as error:
            raise RuntimeError(
                f"Could not connect to Ollama: {error}"
            ) from error

        return {
            "answer": answer,
            "sources": selected
        }
