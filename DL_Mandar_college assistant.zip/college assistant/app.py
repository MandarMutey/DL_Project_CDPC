
from pathlib import Path

import streamlit as st

from rag import KnowledgeAssistant, DEFAULT_DOCS_DIR

st.set_page_config(
    page_title="College Knowledge Assistant",
    page_icon="🎓"
)

st.title("🎓 College Knowledge Assistant")
st.write(
    "Ask questions using the indexed college documents."
)

with st.sidebar:
    st.header("Knowledge Base")

    uploaded_files = st.file_uploader(
        "Upload PDF or TXT documents",
        type=["pdf", "txt"],
        accept_multiple_files=True
    )

    if st.button("Ingest Documents"):
        upload_dir = Path("uploaded_documents")
        upload_dir.mkdir(exist_ok=True)

        for uploaded_file in uploaded_files or []:
            destination = upload_dir / uploaded_file.name
            destination.write_bytes(
                uploaded_file.getbuffer()
            )

        directories = [DEFAULT_DOCS_DIR]

        if uploaded_files:
            directories.append(upload_dir)

        try:
            with st.spinner("Indexing documents..."):
                assistant = KnowledgeAssistant()
                count = assistant.ingest(directories)

            st.session_state["ready"] = True
            st.success(
                f"Successfully indexed {count} chunks."
            )

        except Exception as error:
            st.error(str(error))

if "history" not in st.session_state:
    st.session_state["history"] = []

for item in st.session_state["history"]:
    with st.chat_message(item["role"]):
        st.markdown(item["content"])

        if item.get("sources"):
            with st.expander("Supporting Sources"):
                for source in item["sources"]:
                    st.markdown(
                        f"**{source['source']}** "
                        f"— {source['location']}"
                    )
                    st.write(source["text"])

question = st.chat_input(
    "Ask a question about college policies..."
)

if question:
    st.session_state["history"].append({
        "role": "user",
        "content": question
    })

    with st.chat_message("user"):
        st.write(question)

    with st.chat_message("assistant"):
        try:
            assistant = KnowledgeAssistant()
            result = assistant.answer(question)

            st.markdown(result["answer"])

            if result["sources"]:
                with st.expander(
                    "Supporting Sources",
                    expanded=True
                ):
                    for source in result["sources"]:
                        st.markdown(
                            f"**{source['source']}** "
                            f"— {source['location']} "
                            f"— similarity: "
                            f"{source['score']:.3f}"
                        )
                        st.write(source["text"])

            st.session_state["history"].append({
                "role": "assistant",
                "content": result["answer"],
                "sources": result["sources"]
            })

        except Exception as error:
            st.error(str(error))
